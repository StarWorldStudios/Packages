import os,sys,requests
import random,time,json
import hashlib,platform
import colorlib
import libs
from colorlib import cprint
import execjs
import lupa
import ctypes,tkinter,turtle,traceback,easygui

#Analysis By StarWorldStudio
version = "1.0.1"
echo = True
def senderror(code="ErrorCode",line=0,types="ErrorType:FatalError",file="stdin",runs="module"):
    try:
        lines = int(line)
        line1 = int(lines)+1
    except BaseException:
        lines = -1
    #cprint("An internal error occurred while attempting to perform this statement","DarkRed")
    cprint("Traceback (most recent call last): ","DarkRed")
    cprint(f"  File \"<{file}>\", line {str(line1)}, in <{runs}>: ","DarkRed")
    cprint(f"        \""+code+"\"","DarkRed")
    cprint(f"{types}","DarkRed")

def run(code,line,file="stdin"):
    if (code[0:5] == 'print'):
        try:  
            args = ""
            i = 0
            cont = tuple(str(eval(str(code[6:len(code)]))))
            for i in range(len(cont)):
                args = args + cont[i]
            print(args,end="")
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif (code[0:6] == 'system'):
        try:  
            args = ""
            i = 0
            cont = tuple(str(eval(str(code[7:len(code)]))))
            for i in range(len(cont)):
                args = args + cont[i]
            print(os.popen(args).read())
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif (code[0:6] == 'log_js'):
        try:  
            args = ""
            i = 0
            cont = tuple(str(eval(str(code[7:len(code)]))))
            for i in range(len(cont)):
                args = args + cont[i]
            print(execjs.eval(args),end="")
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif (code[0:6] == "run_py"):
        try:  
            args = ""
            i = 0
            cont = tuple(str(eval(str(code[7:len(code)]))))
            for i in range(len(cont)):
                args = args + cont[i]
            exec(args)
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif (code[0:6] == "ex_lua"):
        try:  
            args = ""
            i = 0
            cont = tuple(str(eval(str(code[7:len(code)]))))
            for i in range(len(cont)):
                args = args + cont[i]
            lua = lupa.LuaRuntime()
            lua.eval(args)
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif (code[0:9] == "brainfuck"):
        try:  
            args = ""
            i = 0
            cont = tuple(str(eval(str(code[10:len(code)]))))
            for i in range(len(cont)):
                args = args + cont[i]
            brainfuck(args)
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif (code[0:7] == "include"):
        try:  
            args = ""
            i = 0
            cont = tuple(str(eval(str(code[8:len(code)]))))
            for i in range(len(cont)):
                args = args + cont[i]
            __import__(args)
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif code.isspace() == True or code == "":
        pass
    elif code == "exit":
        cprint("Use exit() or Ctrl-Z plus Return to exit","Red")
    elif code == "":
        exit(1)
    elif code == "exit()":
        exit(0)
    else:
        senderror(code=code,line=line,types="NameError: name '"+code.split(" ")[0]+"' is not defined")

def brainfuck(code):
    data = [0 for i in range(1000)]
    pc = 0
    ptr = 0
    skip_loop = False
    bracket_count = 0
    stack = []
    while pc < len(code):
        c = code[pc]
        if skip_loop :
            if c =='[':
                bracket_count+=1
            elif c==']':
                bracket_count -=1
                if bracket_count==0:
                    skip_loop =False
            pc+=1
            continue
        if c == '>':
            ptr +=1
            pc +=1
        elif c == '<':
            ptr -=1
            pc +=1
        elif c == '+':
            data[ptr] +=1
            pc +=1
        elif c == '-':
            data[ptr] -=1
            pc +=1
        elif c == '.':
            print(chr(data[ptr]),end="")
            pc +=1
        elif c == ',':
            pc +=1
        elif c == '[':
            if data[ptr] == 0:
                bracket_count = 1
                skip_loop = True
                pc+=1
            else:
                pc+=1
                stack.append(pc)
        elif c == ']':
            if data[ptr] == 0:
                pc+=1
                stack.pop()
            else:
                pc = stack[len(stack)-1]