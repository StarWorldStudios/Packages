import os,sys,requests
import random,time,json
import hashlib,platform,colorlib,libs

#Analysis By StarWorldStudio
version = "1.0.0"
echo = True

def senderror(code="ErrorCode",line=0,types="ErrorType:FatalError",file="stdin",runs="module"):
    try:
        lines = int(line)
        line1 = int(lines)+1
    except BaseException:
        lines = -1
    colorlib.cprint("Traceback (most recent call last): ","DarkRed")
    colorlib.cprint(f"  File \"<{file}>\", line {str(line1)}, in <{runs}>: ","DarkRed")
    colorlib.cprint(f"        \""+code+"\"","DarkRed")
    colorlib.cprint(f"{types}","DarkRed")

def run(code,line,file="stdin"):
    if (code[0:5] == 'print'):
        try:  
            args = ""
            i = 0
            cont = tuple(eval(str(code[5:len(code)])))
            for i in range(len(cont)):
                args = args + cont[i]
            print(args)
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif (code[0:6] == 'system'):
        try:  
            args = ""
            i = 0
            cont = tuple(eval(str(code[6:len(code)])))
            for i in range(len(cont)):
                args = args + cont[i]
            os.system(args)
        except BaseException:
            senderror(code=code,types=f"{sys.exc_info()[0].__name__}: {sys.exc_info()[1]}",line=line,file=file)
    elif code.isspace() == True or code == "" or code[0:1] == '#':
        pass
    else:
        senderror(code=code,line=line,types=f"NameError: name '{code}' is not defined")