import ctypes
  
STD_INPUT_HANDLE = -10  
STD_OUTPUT_HANDLE= -11  
STD_ERROR_HANDLE = -12  
  
FOREGROUND_DARKBLUE = 0x01 # 暗蓝色
FOREGROUND_DARKGREEN = 0x02 # 暗绿色
FOREGROUND_DARKSKYBLUE = 0x03 # 暗天蓝色
FOREGROUND_DARKRED = 0x04 # 暗红色
FOREGROUND_DARKPINK = 0x05 # 暗粉红色
FOREGROUND_DARKYELLOW = 0x06 # 暗黄色
FOREGROUND_DARKWHITE = 0x07 # 暗白色
FOREGROUND_DARKGRAY = 0x08 # 暗灰色
FOREGROUND_BLUE = 0x09 # 蓝色
FOREGROUND_GREEN = 0x0a # 绿色
FOREGROUND_SKYBLUE = 0x0b # 天蓝色
FOREGROUND_RED = 0x0c # 红色
FOREGROUND_PINK = 0x0d # 粉红色
FOREGROUND_YELLOW = 0x0e # 黄色
FOREGROUND_WHITE = 0x0f # 白色
 
std_out_handle=ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
 
def set_cmd_text_color(color, handle=std_out_handle):
    Bool=ctypes.windll.kernel32.SetConsoleTextAttribute(handle, color)
    return Bool
 
def resetColor():
    set_cmd_text_color(FOREGROUND_DARKWHITE)
 
def cprint(mess,color,endl=None):
    if color=='DarkBlue':
        set_cmd_text_color(FOREGROUND_DARKBLUE)
 
    elif color=='DarkGreen':
        set_cmd_text_color(FOREGROUND_DARKGREEN)
 
    elif color=='DarkSkyBlue':
        set_cmd_text_color(FOREGROUND_DARKSKYBLUE)
        
    elif color=='DarkRed':
        set_cmd_text_color(FOREGROUND_DARKRED)
 
    elif color=='DarkPink':
        set_cmd_text_color(FOREGROUND_DARKPINK)
        
    elif color=='DarkYellow':
        set_cmd_text_color(FOREGROUND_DARKYELLOW)
 
    elif color=='DarkWhite':
        set_cmd_text_color(FOREGROUND_DARKWHITE)
 
    elif color=='DarkGray':
        set_cmd_text_color(FOREGROUND_DARKGRAY)
 
    elif color=='Blue':
        set_cmd_text_color(FOREGROUND_BLUE)
 
    elif color=='Green':
        set_cmd_text_color(FOREGROUND_GREEN)
 
    elif color=='SkyBlue':
        set_cmd_text_color(FOREGROUND_SKYBLUE)
 
    elif color=='Red':
        set_cmd_text_color(FOREGROUND_RED)
 
    elif color=='Pink':
        set_cmd_text_color(FOREGROUND_PINK)
 
    elif color=='Yellow':
        set_cmd_text_color(FOREGROUND_YELLOW)
 
    elif color=='White':
        set_cmd_text_color(FOREGROUND_WHITE)
    print(mess,end=endl)
    resetColor()
 
#cprint(message,color)

