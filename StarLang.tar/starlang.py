import os,sys,analysis
import ctypes,colorlib
import libs,platform,hashlib
import time

tags = hashlib.md5()
tags.update(f"{analysis.version}".encode('utf-8'))

ctypes.windll.kernel32.SetConsoleTitleW(f"StarWorldLang v{analysis.version}")
argv = sys.argv
if len(argv) > 1:
    try:
        with open(argv[1],mode="r",encoding='UTF-8') as code:
            cons = code.read()
            line = cons.split("\n")
            count = len(open(argv[1], 'r').readlines())
            for i in range(0,count):
                analysis.run(line[i],i,file=argv[1])
                i = i + 1
    except BaseException:
        colorlib.cprint("An internal fatal error occurred while executing the command","DarkRed")
elif len(argv) <= 1: 
    colorlib.cprint(f"StarLang {analysis.version} (tags/v{analysis.version}:{tags.hexdigest()},{time.asctime(time.localtime(time.time()))})  [{platform.machine()}] on {platform.architecture()[1]} {platform.architecture()[0]}\n","Blue")                                  
    while True:
        colorlib.set_cmd_text_color(colorlib.FOREGROUND_GREEN)
        codes = input(">>>")
        colorlib.resetColor()
        analysis.run(codes,0)
